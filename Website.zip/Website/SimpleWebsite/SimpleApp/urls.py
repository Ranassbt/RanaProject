from django.urls import path
from . import views


urlpatterns = [
    path('',views.great, name='home-page'),
]
