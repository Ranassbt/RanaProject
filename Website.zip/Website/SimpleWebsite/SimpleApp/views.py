from django.shortcuts import render
from django.http import HttpResponse

def great(request):
    return render(request,'SimpleApp/index.html')