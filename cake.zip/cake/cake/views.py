from django.shortcuts import render
# from django.http import HttpResponse
from info.models import index_info
from products.models import Products

def home(request):
    data=index_info.objects.all()
    dict={
        'info':data,
    }
    return render(request,'index.html',dict)

def about(request):
    return render(request,'about.html')

def testimonial(request):
    data=index_info.objects.all()
    dict={
        'info':data
    }
    
    return render(request,'testimonial.html',dict)


def products(request):
    prod=Products.objects.all()
    dict={
        'prod':prod
    }
    return render(request,'products.html',dict)


def prices(request):
    return render(request,'prices.html')